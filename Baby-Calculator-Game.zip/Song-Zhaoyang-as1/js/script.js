/* script.js 
   Author:
   Date:
*/


$(document).ready(function(){ // begin document.ready block
   // Your jQuery code here...
  let clickedNumberSum = 0;

  $("#submitButton").click(function() {
    let name = $('#nameInput').val();
    $("#name").text(", " + name + "!");
  });

 	
  $(".image").click(function() {
    let clickedImg = $(this).attr("src");
    $("#displayImg").attr({src: clickedImg});
    let clickedNumber = parseInt($(this).attr("data-value"));
    clickedNumberSum += clickedNumber;
    $("#total").text(clickedNumberSum);
  });

  $("#clearButton").click(function() {
    let clearButton = 0;
    clickedNumberSum = 0;
    $("#total").text(clickedNumberSum);
  });

}); 




